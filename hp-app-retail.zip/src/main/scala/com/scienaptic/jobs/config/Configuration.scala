package com.scienaptic.jobs.config

trait Configuration {

}
