package com.scienaptic.jobs.utility

object Retailutility {

}
