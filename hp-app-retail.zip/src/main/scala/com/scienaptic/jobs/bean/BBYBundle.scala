package com.scienaptic.jobs.bean

case class BBYBundle(`Week Ending`: String, `BBY SKU`: Int, `SKU Name`: String, `B&M Units`: String, `_COM Units`: String, Units: String, `Bundle Rebate`: String, `HP SKU`: String)

case class BBYBundleTranspose(`Week Ending`: String, Units: String, `HP SKU`: String, Online: String, `Bundle Qty Raw`: String)


