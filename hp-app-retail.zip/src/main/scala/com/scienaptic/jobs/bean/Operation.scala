package com.scienaptic.jobs.bean

abstract class Operation {
  def scienapticDef(): Any
}
